import java.util.Random;
import java.util.Scanner;

public class BombChance {
    public void placeBomb(int [][] grid)
    {
        Random rand=new Random();
        int[] goodbomb1=new int[2];
        int[] goodbomb2=new int[2];
        int[] badbomb1=new int[2];
        int[] badbomb2=new int[2];
        int[] badbomb3=new int[2];

        for (int i=0;i<4;)
        {
            goodbomb1[0]=rand.nextInt(4);
            goodbomb1[1]=rand.nextInt(4);
            grid [goodbomb1[0]][goodbomb1[1]]=1;
            goodbomb2[0]=rand.nextInt(4);
            goodbomb2[1]=rand.nextInt(4);
            if (grid[goodbomb2[0]][goodbomb2[1]]==0)
            {
                grid[goodbomb2[0]][goodbomb2[1]]=1;
                i++;
            }

            badbomb1[0]=rand.nextInt(4);
            badbomb1[1]=rand.nextInt(4);
            if (grid[badbomb1[0]][badbomb2[1]]==0)
            {
                grid[badbomb1[0]][badbomb2[1]]=-1;
                i++;
            }

            badbomb2[0]=rand.nextInt(4);
            badbomb2[1]=rand.nextInt(4);
            if (grid[badbomb2[0]][badbomb2[1]]==0)
            {
                grid[badbomb2[0]][badbomb2[1]]=-1;
                i++;
            }

            badbomb3[0]=rand.nextInt(4);
            badbomb3[1]=rand.nextInt(4);
            if (grid[badbomb3[0]][badbomb3[1]]==0)
            {
                grid[badbomb3[0]][badbomb3[1]]=-1;
                i++;
            }
        }
    }

    public void placeNumber(int [][] grid)
    {
        Scanner sc=new Scanner(System.in);
        int row ,col;
        boolean [] number=new boolean[10];

        do {
            System.out.print("Enter row number (0-3):");
            row=sc.nextInt();

        }while(row>3 || row<0);

        do {
           System.out.print("Enter column number (0-3) :");
           col=sc.nextInt();

        }while(col>3 || col<0);
        int user_input;

        if (grid[row][col]==0)
        {
            System.out.println("Enter number between 1-9: ");
            user_input=sc.nextInt();
            if (number[user_input]==false)
            {
                number[user_input]=true;
                grid[row][col]=user_input;
            }
        }

        if (grid[row][col]==1)
        {
            System.out.println("Enter number between 1-9: ");
            user_input=sc.nextInt();
            if (number[user_input]==false)
            {
                number[user_input]=true;
                grid[row][col]=user_input*2;
            }
        }

        if (grid[row][col]==-1)
        {
            System.out.println("Enter number between 1-9: ");
            user_input=sc.nextInt();
            if (number[user_input]==false)
            {
                number[user_input]=true;
                grid[row][col]=user_input*0;
            }
        }
    }
}

public class Main {
    public static void main(String[] args) {
        int[][] grid=new int[4][4];


    }
}

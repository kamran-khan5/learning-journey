import java.util.Random;
import java.util.Scanner;

public class Main {
    public static char [][] grid= new char[6][6];
    public static int collectedGem;

    public static void placeDashes()
    {
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                grid[i][j] = '-';

            }
        }
    }
    public static void placeBomb ()
    {
        Random rand=new Random(6);
        for (int i=0;i<5;i++)
        {
            int row=rand.nextInt();
            int col=rand.nextInt();
            if (grid[row][col]!='b')
            {
                grid[row][col]= 'b';
                i++;
            }
        }
    }

    public static void placeGem ()
    {
        Random rand=new Random(6);
        for (int i=0;i<5;)
        {
            int row=rand.nextInt();
            int col=rand.nextInt();
            if (grid[row][col]!='b' && grid[row][col]!='g')
            {
                grid[row][col]= 'g';
                i++;
            }
        }
    }

    public static void cellUncovering() {
        int row, col;
        Scanner sc = new Scanner(System.in);
        do {
            do {
                System.out.print("Enter row no between (1-6): ");
                row = sc.nextInt();
            } while (row < 1 || row > 6);

            do {
                System.out.print("Enter column no between (1-6): ");
                col = sc.nextInt();
            } while (col < 1 || col > 6);
            
            if (grid[row-1][col-1]=='U')
            {
                System.out.println("This Slot is Already Uncover... Try Again");
            }
            
        }while (grid[row-1][col-1]=='U');

        if (grid[row - 1][col - 1] == 'g') {
            collectedGem++;
            grid[row - 1][col - 1] = 'G';
            System.out.println("Great you got a Gem... ");
        } else if (grid[row-1][col-1]=='b') {
            if(col-1==0)
            {
                for ( int i = row-1; i < row+1; i++) {
                    for ( int j = 0; j < col+1; j++) {
                        grid[i][j]='*';

                    }

                }
            } else if (col-1==5) {
                for ( int i = row-1; i < row+1; i++) {
                    for ( int j = col-1; j < col; j++) {
                        grid[i][j]='*';

                    }

                }


            } else if (row-1==0) {
                for ( int i = row; i < row+1; i++) {
                    for ( int j = col-1; j < col+1; j++) {
                        grid[i][j]='*';

                    }

                }

            } else if (row-1==5) {
                for ( int i = row-1; i < row; i++) {
                    for ( int j = col-1; j < col+1; j++) {
                        grid[i][j]='*';

                    }

                }
            }else
            {
                for ( int i = row-1; i < row+1; i++) {
                    for ( int j = col-1; j < col+1; j++) {
                        grid[i][j]='*';

                    }

                }
            }
        }else
        {
            grid[row][col]='U';
        }
        gridShow();
    }

    

    public static void gridShow()
    {
        for (int i=0;i<6;i++)
        {
            for (int j=0;j<6;j++)
            {
                if (grid[i][j]=='b' || grid[i][j]=='g')
                {
                    System.out.print("-\t");
                }
                else
                {
                    System.out.print(grid[i][j]+"\t");
                }
            }
            System.out.println("\n");
        }

    }
    
    public static void main(String[] args) {
        System.out.println("Welcome to Game!");
        placeDashes();
        gridShow();
        placeBomb();
        placeGem();
        for (int i=0;i<6;i++)
        {
            for (int j=0;j<6;j++)
            {
                cellUncovering();
            }
        }
    }
}